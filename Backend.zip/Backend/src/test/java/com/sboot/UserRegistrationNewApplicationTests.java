package com.sboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegistrationNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
