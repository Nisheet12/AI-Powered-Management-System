package com.sboot.controller;
 
import com.sboot.entity.RawMaterial;

import com.sboot.entity.Supplier;

import com.sboot.service.SupplierService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;
 
import java.util.List;
 
@RestController

@RequestMapping("/suppliers")

@CrossOrigin(origins = "*") // Allow Angular to call

//CRUD for supplier

public class SupplierController {
 
    @Autowired

    private SupplierService supplierService;
 
    // ✅ 1. Add supplier

    @PostMapping("/add")

    public Supplier createSupplier(@RequestBody Supplier supplier) {

        return supplierService.addSupplier(supplier);

    }
 
    // ✅ 2. Update supplier

    @PutMapping("/{id}")

    public Supplier updateSupplier(@PathVariable Long id, @RequestBody Supplier supplier) {

        return supplierService.updateSupplier(id, supplier);

    }
 
    // ✅ 3. Get all suppliers

    @GetMapping

    public List<Supplier> getAllSuppliers() {

        return supplierService.getAllSuppliers();

    }
 
    // ✅ 4. Get supplier by ID

    @GetMapping("/{id}")

    public Supplier getSupplierById(@PathVariable Long id) {

        return supplierService.getSupplierById(id);

    }
 
    // ✅ 5. Delete supplier

    @DeleteMapping("/{id}")

    public String deleteSupplier(@PathVariable Long id) {

        supplierService.deleteSupplier(id);

        return "Supplier deleted successfully with ID: " + id;

    }


   //............................................

// ✅ API to get all raw materials

    @GetMapping("/rawMaterial")

    public List<RawMaterial> getAllRawMaterials() {

        return supplierService.getAllRawMaterials();

    }

}

 