package com.sboot.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.sboot.dto.UserDto;
import com.sboot.entity.Role;
import com.sboot.entity.User;
import com.sboot.repository.RoleRepository;
import com.sboot.repository.UserRepository;
import com.sboot.service.SecuredPasswordGenerator;
import com.sboot.service.UserService;
import com.sboot.service.MailService.MailService;

@CrossOrigin(origins ="http://localhost:4200")
@RestController
@RequestMapping("/api/users")
public class UserController {

    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private MailService emailService;

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private UserRepository userRepository;

    /** ------------------- USER MANAGEMENT ------------------- **/

    @PostMapping("/register")
    public ResponseEntity<UserDto> registerUser(@RequestBody User user) {
        User saved = userService.registerUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(UserDto.fromEntity(saved));
    }

    @GetMapping
    public ResponseEntity<List<UserDto>> getAllUsers() {
        List<UserDto> users = userService.getAllUsers()
                .stream().map(UserDto::fromEntity).toList();
        return ResponseEntity.ok(users);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UserDto> updateUser(@PathVariable String id, @RequestBody User updatedUser) {
        User saved = userService.updateUser(id, updatedUser);
        return ResponseEntity.ok(UserDto.fromEntity(saved));
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUser(@PathVariable String id) {
        return ResponseEntity.ok(UserDto.fromEntity(userService.getUserById(id)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable String id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(Map.of("message", "User deleted successfully"));
    }

    /** ------------------- PASSWORD MANAGEMENT ------------------- **/

    @PutMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(@RequestBody ResetPasswordRequest request, Principal principal) {
        String username = principal.getName();
        log.info("Password reset request for principal: {}", username);

        Optional<User> userOpt = userService.getUserByUsername(username)
                .or(() -> userService.getByEmail(username));

        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "User not found."));
        }

        User user = userOpt.get();
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getUserPassword())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("message", "Current password is incorrect."));
        }

        if (passwordEncoder.matches(request.getNewPassword(), user.getUserPassword())) {
            return ResponseEntity.badRequest().body(Map.of("message", "New password must be different from old password."));
        }

        user.setUserPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setMustReset(false);
        userService.saveUser(user);

        return ResponseEntity.ok(Map.of("message", "Password reset successfully."));
    }

    @PostMapping("/send-otp")
    public ResponseEntity<Map<String, String>> sendOtp(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        if (email == null || email.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email is required."));
        }
        emailService.generateAndStoreOtp(email);
        return ResponseEntity.ok(Map.of("message", "OTP sent to email."));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, String>> verifyOtp(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String otp = request.get("otp");

        if (email == null || email.isBlank() || otp == null || otp.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email and OTP are required."));
        }

        return emailService.verifyOtp(email, otp)
                ? ResponseEntity.ok(Map.of("message", "OTP verified."))
                : ResponseEntity.badRequest().body(Map.of("message", "Invalid OTP."));
    }

    @PostMapping("/reset-password-with-otp")
    public ResponseEntity<Map<String, String>> resetPasswordWithOtp(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        String otp = request.get("otp");
        String newPassword = request.get("newPassword");

        if (email == null || email.isBlank() || otp == null || otp.isBlank() || newPassword == null || newPassword.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email, OTP and new password are required."));
        }

        Optional<User> opt = userRepository.findByEmail(email);
        if (opt.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "User not found with this email."));
        }

        User user = opt.get();

        if ("ADMIN".equalsIgnoreCase(user.getRole().getRoleName())) {
            return ResponseEntity.badRequest().body(Map.of("message", "Admin password cannot be reset via OTP."));
        }

        if (!emailService.verifyOtp(email, otp)) {
            return ResponseEntity.badRequest().body(Map.of("message", "Invalid OTP."));
        }

        if (passwordEncoder.matches(newPassword, user.getUserPassword())) {
            return ResponseEntity.badRequest().body(Map.of("message", "New password must be different from the old one."));
        }

        userService.updatePassword(email, newPassword);
        return ResponseEntity.ok(Map.of("message", "Password reset successfully."));
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> forgotPassword(@RequestParam String email) {
        Optional<User> optionalUser = userService.getByEmail(email);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "No user found with that email."));
        }

        User user = optionalUser.get();
        String tempPassword = SecuredPasswordGenerator.generatePassword();
        user.setUserPassword(passwordEncoder.encode(tempPassword));
        user.setMustReset(true);
        userService.saveUser(user);

        emailService.sendEmail(
            user.getUserEmail(),
            "Password Reset Request",
            "Your temporary password is: " + tempPassword + "\nPlease log in and reset your password."
        );

        return ResponseEntity.ok(Map.of("message", "Temporary password sent to your email."));
    }

    /** ------------------- ROLE MANAGEMENT ------------------- **/

    @GetMapping("/roles")
    public ResponseEntity<List<Role>> getAllRoles() {
        return ResponseEntity.ok(roleRepo.findAll());
    }

    /** ------------------- SEARCH ------------------- **/

    @GetMapping("/search")
    public ResponseEntity<List<UserDto>> searchUsers(@RequestParam String query) {
        // You probably want to support multiple results, not Optional<User>
        List<UserDto> result = userService.getAllUsers()
                .stream()
                .filter(u -> u.getUserEmail().contains(query) || u.getUserFullName().contains(query))
                .map(UserDto::fromEntity)
                .toList();
        return ResponseEntity.ok(result);
    }

    /** ------------------- ACCOUNT UNLOCK ------------------- **/
    
    @GetMapping("/locked-users")
    public ResponseEntity<List<User>> getLockedUsers() {
        List<User> lockedUsers = userRepository.findByAccountLockedAtIsNotNull();
 
        if (lockedUsers.isEmpty()) {
            return ResponseEntity.ok(List.of()); // return empty JSON array
        }
 
        return ResponseEntity.ok(lockedUsers);
    }
 
    
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/unlock-account")
    public ResponseEntity<Map<String, String>> unlockAccount(@RequestParam String email) {
        Optional<User> opt = userRepository.findByEmail(email);
        if (opt.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("message", "User not found."));
        }

        User user = opt.get();
        if (user.getAccountLockedAt() == null) {
            return ResponseEntity.ok(Map.of("message", "Account is not locked."));
        }

        user.setFailedLoginAttempts(0);
        user.setAccountLockedAt(null);
        userRepository.save(user);

        emailService.sendSimpleMessage(
            user.getUserEmail(),
            "Account Unlocked",
            "Dear " + user.getUserFullName() + ",\n\nYour account has been unlocked by the administrator.\n\nThank you."
        );

        return ResponseEntity.ok(Map.of("message", "Account unlocked successfully."));
    }

    /** ------------------- DTO ------------------- **/

    public static class ResetPasswordRequest {
        private String currentPassword;
        private String newPassword;

        public String getCurrentPassword() { return currentPassword; }
        public void setCurrentPassword(String currentPassword) { this.currentPassword = currentPassword; }
        public String getNewPassword() { return newPassword; }
        public void setNewPassword(String newPassword) { this.newPassword = newPassword; }
    }
}
