package com.sboot.controller;

public class SupplierHistory {
	
	//need to add 

}
