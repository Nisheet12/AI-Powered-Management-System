package com.sboot.service;
 
import com.sboot.entity.RawMaterial;

import com.sboot.entity.Supplier;

import com.sboot.repository.RawMaterialsRepository;

import com.sboot.repository.SuppliersRepository;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
 
import java.util.List;
 
@Service

public class SupplierService {
 
    @Autowired

    private SuppliersRepository supplierRepository;

    @Autowired

    private RawMaterialsRepository rawMaterialsRepository;
 
    // ✅ Add new supplier

    public Supplier addSupplier(Supplier supplier) {

        return supplierRepository.save(supplier);

    }
 
    // ✅ Update supplier

    public Supplier updateSupplier(Long supplierId, Supplier updatedSupplier) {

        Supplier existingSupplier = supplierRepository.findById(supplierId)

                .orElseThrow(() -> new RuntimeException("Supplier not found with ID: " + supplierId));
 
        existingSupplier.setSuppliersName(updatedSupplier.getSuppliersName());

        existingSupplier.setSuppliersPhone(updatedSupplier.getSuppliersPhone());

        existingSupplier.setSuppliersEmail(updatedSupplier.getSuppliersEmail());

        existingSupplier.setSuppliersContactPerson(updatedSupplier.getSuppliersContactPerson());

        existingSupplier.setAddress(updatedSupplier.getAddress());
 
        return supplierRepository.save(existingSupplier);

    }
 
    // ✅ Get all suppliers

    public List<Supplier> getAllSuppliers() {

        return supplierRepository.findAll();

    }
 
    // ✅ Get supplier by ID

    public Supplier getSupplierById(Long id) {

        return supplierRepository.findById(id)

                .orElseThrow(() -> new RuntimeException("Supplier not found with ID: " + id));

    }
 
    // ✅ Delete supplier

    public void deleteSupplier(Long id) {

        Supplier supplier = supplierRepository.findById(id)

                .orElseThrow(() -> new RuntimeException("Supplier not found with ID: " + id));
 
        supplierRepository.delete(supplier);

    }


    //..........................................

// ✅ Get all raw materials

    public List<RawMaterial> getAllRawMaterials() {

        return rawMaterialsRepository.findAll();

    }

}

 