package com.sboot.service;
import com.sboot.entity.Address;
import com.sboot.entity.Role;
import com.sboot.entity.User;
import com.sboot.repository.AddressRepository;
import com.sboot.repository.RoleRepository;
import com.sboot.repository.UserRepository;
import com.sboot.service.MailService.MailService;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
 
@Service
public class UserService {
 
    private final UserRepository userRepository;
    private final AddressRepository addressRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final MailService mailService;
 
    @Autowired
    public UserService(UserRepository userRepository,
                       AddressRepository addressRepository,
                       RoleRepository roleRepository,
                       PasswordEncoder passwordEncoder,
                       MailService mailService) {
        this.userRepository = userRepository;
        this.addressRepository = addressRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.mailService=mailService;
        
    }
 
public User registerUser(User user) {
    	
    	String generatedUserId = generateCustomUserId(user);
        user.setUserId(generatedUserId);
    	
        if (userRepository.existsByUserEmail(user.getUserEmail())) {
            throw new RuntimeException("Email already in use");
        }
 
        // Save address
        if (user.getAddress() != null) {
            Address savedAddress = addressRepository.save(user.getAddress());
            user.setAddress(savedAddress);
        }
 
        // Set role
        Role role = roleRepository.findById(user.getRole().getRoleId())
        		
                .orElseThrow(() -> new RuntimeException("Role not found"));
        user.setRole(role);
 
        String plainPassword;
 
        // Handle password
        if (user.getUserPassword() == null || user.getUserPassword().isBlank()) {
            // Auto-generate temp password
            plainPassword = UUID.randomUUID().toString().substring(0, 8);
            user.setUserPassword(passwordEncoder.encode(plainPassword));
        } else {
            // Use provided password
            plainPassword = user.getUserPassword(); // Save plain version to send in email
            user.setUserPassword(passwordEncoder.encode(plainPassword));
        }
        
        
        user.setMustReset(true);
 
        // Save user
        User savedUser = userRepository.save(user);
        
        
 
 
        // Send email with credentials
        mailService.sendEmail(
            user.getUserEmail(),
            "Welcome to Order Craft - Your Login Credentials",
            "Hello " + user.getUserFullName() + ",\n\n" +
            "Your account has been created.\n\n" +
            "Login Username: " + user.getUserEmail() + "\n" +
            "Password: " + plainPassword + "\n\n" +
            "Please login and reset your password.\n\n" +
            "Regards,\nOrder Craft Admin Team"
        );
 
        return savedUser;
    }


public Optional<User> searchByEmailOrName(String query) {
    return userRepository.findByEmail( query);
}

public List<User> getAllUsers() {
    return userRepository.findAll();
}


private String generateCustomUserId(User user) {
    // 1. Get role prefix
    String rolePrefix = switch (user.getRole().getRoleName()) {
        case "PROCUREMENT_OFFICER" -> "PO";
        case "INVENTORY_MANAGER" -> "IM";
        case "ADMIN" -> "AD";
        case "PRODUCTION_MANAGER" -> "PM";
        default -> "XX";
    };

    // 2. Get city code (first 3 letters of city)
    String cityCode = Optional.ofNullable(user.getAddress())
        .map(a -> a.getAddressCity())
        .filter(city -> city.length() >= 3)
        .map(city -> city.substring(0, 3).toUpperCase())
        .orElse("LOC");

    // 3. Generate a random 4-digit number
    int randomNumber = new Random().nextInt(9000) + 1000;

    return rolePrefix + cityCode + randomNumber;
}
 
    public User getUserById(String id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }
 
    public void deleteUser(String id) {
        if (!userRepository.existsById(id)) {
            throw new RuntimeException("User not found with ID: " + id);
        }
        userRepository.deleteById(id);
    }
 
    public User updateUser(String id, User updatedUser) {
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
 
        existingUser.setUserFullName(updatedUser.getUserFullName());
        existingUser.setUserEmail(updatedUser.getUserEmail());
        existingUser.setUserMobile(updatedUser.getUserMobile());
        existingUser.setUserProfileImg(updatedUser.getUserProfileImg());
 
        if (updatedUser.getUserPassword() != null && !updatedUser.getUserPassword().isBlank()) {
            existingUser.setUserPassword(passwordEncoder.encode(updatedUser.getUserPassword()));
        }
 
        if (updatedUser.getAddress() != null) {
            Address savedAddress = addressRepository.save(updatedUser.getAddress());
            existingUser.setAddress(savedAddress);
        }
 
        if (updatedUser.getRole() != null) {
            Role role = roleRepository.findById(updatedUser.getRole().getRoleId())
                    .orElseThrow(() -> new RuntimeException("Role not found"));
            existingUser.setRole(role);
        }
 
        return userRepository.save(existingUser);
    }

	public Optional<User> getByEmail(String username) {
		return userRepository.findByEmail(username);
	}

	public void saveUser(User user) {
		userRepository.save(user);
		
	}

	public Optional<User> getUserByUsername(String username) {
	    return userRepository.findByUserName(username);
	}
	
	
	public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
    }

    public void updatePassword(String email, String newPassword) {
        User user = findByEmail(email);
        user.setUserPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }


	
}