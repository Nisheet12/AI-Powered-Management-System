package com.sboot.service;

public class SupplierHistory {

}
