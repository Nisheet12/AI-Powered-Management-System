package com.sboot.service;

import com.sboot.dto.SupplierRatingRequest;
import com.sboot.dto.SupplierRatingResponse;
import com.sboot.entity.SupplierRating;

public class SupplierRatingMapper {

    public static SupplierRating toEntity(SupplierRatingRequest req) {
        SupplierRating e = new SupplierRating();
        e.setSupplierId(req.getSupplierId());
        // Rating is calculated in the service layer (not directly from request)
        e.setReview(req.getReview());
        return e;
    }

    public static SupplierRatingResponse toDto(SupplierRating e) {
        SupplierRatingResponse dto = new SupplierRatingResponse();
        dto.setId(e.getId());
        dto.setSupplierId(e.getSupplierId());
        dto.setRating(e.getRating());
        dto.setReview(e.getReview());
        // dto.setCreatedAt(e.getCreatedAt()); // Optional: Uncomment if needed
        dto.setUpdatedAt(e.getUpdatedAt());
        return dto;
    }
}
