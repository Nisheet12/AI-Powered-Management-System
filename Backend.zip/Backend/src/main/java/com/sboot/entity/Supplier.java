package com.sboot.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "SUPPLIERS")
public class Supplier {
	
    @Id
    @Column(name = "SUPPLIERSID")
    private Long suppliersId;
    
    @Column(name = "SUPPLIERSNAME")
    private String suppliersName;
    
    @Column(name = "SUPPLIERSPHONE")
    private String suppliersPhone;
    
    @Column(name = "SUPPLIERSEMAIL")
    private String suppliersEmail;
    
    @Column(name = "SUPPLIERSCONTACTPERSON")
    private String suppliersContactPerson;

    @ManyToOne
    @JoinColumn(name = "SUPPLIERSADDRESSID", referencedColumnName = "ADDRESSID")
    private Address address;

	public Long getSuppliersId() {
		return suppliersId;
	}

	public void setSuppliersId(Long suppliersId) {
		this.suppliersId = suppliersId;
	}

	public String getSuppliersName() {
		return suppliersName;
	}

	public void setSuppliersName(String suppliersName) {
		this.suppliersName = suppliersName;
	}

	public String getSuppliersPhone() {
		return suppliersPhone;
	}

	public void setSuppliersPhone(String suppliersPhone) {
		this.suppliersPhone = suppliersPhone;
	}

	public String getSuppliersEmail() {
		return suppliersEmail;
	}

	public void setSuppliersEmail(String suppliersEmail) {
		this.suppliersEmail = suppliersEmail;
	}

	public String getSuppliersContactPerson() {
		return suppliersContactPerson;
	}

	public void setSuppliersContactPerson(String suppliersContactPerson) {
		this.suppliersContactPerson = suppliersContactPerson;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
    
    
}
