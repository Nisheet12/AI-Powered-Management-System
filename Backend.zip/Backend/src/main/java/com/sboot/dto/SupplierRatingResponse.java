package com.sboot.dto;

import java.time.Instant;
import java.time.LocalDate;

public class SupplierRatingResponse {
    private Long id;
    private Long supplierId;
    private Integer rating;
    private String review;
    //private Instant createdAt;
    private LocalDate updatedAt;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getSupplierId() { return supplierId; }
    public void setSupplierId(Long supplierId) { this.supplierId = supplierId; }

    public Integer getRating() { return rating; }
    public void setRating(Integer rating) { this.rating = rating; }

    public String getReview() { return review; }
    public void setReview(String review) { this.review = review; }

//    public Instant getCreatedAt() { return createdAt; }
//    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }

    public LocalDate getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDate localDate) { this.updatedAt = localDate; }
}
