package com.sboot.dto;

public class ProductDTO {
    private Long id;
    private String name;
    private Float price;
    private Integer productsquantity;

    public ProductDTO(Long id, String name, Float price, Integer productsquantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.productsquantity = productsquantity;
    }
    public Long getId() { return id; }
    public String getName() { return name; }
    public Float getPrice() { return price; }
    public Integer getProductsQuantity() { return productsquantity;}
}
