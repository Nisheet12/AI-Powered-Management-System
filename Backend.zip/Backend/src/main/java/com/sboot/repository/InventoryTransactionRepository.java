package com.sboot.repository;
 
 
import org.springframework.data.jpa.repository.JpaRepository;
 
import com.sboot.entity.InventoryTransaction;
 


public interface InventoryTransactionRepository extends JpaRepository<InventoryTransaction, Long> {

	InventoryTransaction save(InventoryTransaction txn);
 
    // You can add custom query methods here if needed
 
}

 