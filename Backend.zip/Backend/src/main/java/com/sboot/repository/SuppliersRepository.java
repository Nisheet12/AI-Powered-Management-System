package com.sboot.repository;

import com.sboot.entity.Supplier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SuppliersRepository extends JpaRepository<Supplier, Long> {

    Optional<Supplier> findBySuppliersName(String suppliersName);

    @Query("SELECT s FROM Supplier s WHERE LOWER(s.suppliersName) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Supplier> searchByName(@Param("keyword") String keyword);

    Page<Supplier> findAll(Pageable pageable);

    @Query("SELECT s FROM Supplier s WHERE LOWER(s.suppliersContactPerson) LIKE LOWER(CONCAT('%', :contact, '%'))")
    List<Supplier> findByContactPerson(@Param("contact") String contact);

    Optional<Supplier> findBySuppliersEmail(String suppliersEmail);

    // ===== Option A: JPQL — only use if Address entity has a 'city' property =====
    // Uncomment if your Address.java contains 'private String city;'
    // @Query("SELECT COUNT(s) FROM Supplier s WHERE LOWER(s.address.city) = LOWER(:city)")
    // Long countSuppliersByCity(@Param("city") String city);

    // ===== Option B: Native SQL — use if Address entity does NOT have 'city' but DB has a column (replace column/table names as needed) =====
    // Replace ADDRESS_TABLE and ADDRESS_CITY_COLUMN with actual DB names if different.
    @Query(value = "SELECT COUNT(*) FROM SUPPLIERS s JOIN ADDRESS a ON s.SUPPLIERSADDRESSID = a.ADDRESSID WHERE LOWER(a.ADDRESSCITY) = LOWER(:city)", nativeQuery = true)
    Long countSuppliersByCityNative(@Param("city") String city);

    // Analytics: top suppliers by raw material count (adjust table/column names if necessary)
    @Query("SELECT s.suppliersName, COUNT(rm) FROM Supplier s JOIN RawMaterial rm ON rm.supplier = s GROUP BY s.suppliersName ORDER BY COUNT(rm) DESC")
    List<Object[]> getTopSuppliersByMaterialCount();
}
