package com.sboot.util;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.PdfPCell;
import com.sboot.dto.InvoiceResponseDTO;
import com.sboot.dto.OrderItemDTO;

import java.awt.Color;
import java.io.ByteArrayOutputStream;

public class InvoicePdfGenerator {

    public static byte[] generatePdf(InvoiceResponseDTO invoice) throws Exception {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfWriter.getInstance(document, out);
        document.open();

        // Company Branding
        Font companyFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, new Color(0, 102, 204));
        Paragraph companyName = new Paragraph("OrderCraft", companyFont);
        companyName.setAlignment(Element.ALIGN_CENTER);
        document.add(companyName);

        // Invoice Heading
        Font headingFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16, Color.BLACK);
        Paragraph heading = new Paragraph("Invoice for Order #" + invoice.getOrderId(), headingFont);
        heading.setAlignment(Element.ALIGN_CENTER);
        document.add(heading);
        document.add(Chunk.NEWLINE);

        // Customer Details Section
        Font infoFont = FontFactory.getFont(FontFactory.HELVETICA, 12);
        document.add(new Paragraph("Customer Name: " + invoice.getCustomerName(), infoFont));
        document.add(new Paragraph("Email: " + invoice.getCustomerEmail(), infoFont));
        document.add(new Paragraph("Mobile: " + invoice.getPhoneNumber(), infoFont));
        document.add(new Paragraph("Address: " + invoice.getBillingAddress(), infoFont));
        document.add(Chunk.NEWLINE);

        // Product Table
        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, Color.WHITE);

        // Header Row
        String[] headers = {"Product Name", "Category", "Quantity", "Unit Price"};
        for (String title : headers) {
            PdfPCell headerCell = new PdfPCell(new Paragraph(title, headerFont));
            headerCell.setBackgroundColor(new Color(0, 102, 204));
            table.addCell(headerCell);
        }

        double totalAmount = 0.0;

        // Item Rows
        for (OrderItemDTO item : invoice.getItems()) {
            table.addCell(item.getProductName());
            table.addCell(item.getCategory());
            table.addCell(String.valueOf(item.getQuantity()));
            table.addCell(String.format("₹%.2f", item.getUnitPrice()));
            totalAmount += item.getQuantity() * item.getUnitPrice();
        }

        document.add(table);
        document.add(Chunk.NEWLINE);

        // Totals
        double gst = totalAmount * 0.18;
        double finalAmount = totalAmount + gst;

        Font totalFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, new Color(0, 102, 0));
        document.add(new Paragraph("Subtotal: ₹" + String.format("%.2f", totalAmount), totalFont));
        document.add(new Paragraph("GST (18%): ₹" + String.format("%.2f", gst), totalFont));
        document.add(new Paragraph("Total Amount to Pay: ₹" + String.format("%.2f", finalAmount), totalFont));

        document.close();
        return out.toByteArray();
    }
}
