import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-6QLPAAB6.js";
import "./chunk-ZMKZXQHC.js";
import "./chunk-P3HZPRKV.js";
import "./chunk-ZK6P7H22.js";
import "./chunk-45OQDK62.js";
import "./chunk-YBCPKXH5.js";
import "./chunk-JSFEMK6X.js";
import "./chunk-E5ECCKE6.js";
import "./chunk-3OV72XIM.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
//# sourceMappingURL=@angular_material_icon.js.map
