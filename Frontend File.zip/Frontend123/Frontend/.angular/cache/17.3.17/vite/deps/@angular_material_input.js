import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-US7ZFXPS.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-2U56LQX2.js";
import "./chunk-PU4OD3SX.js";
import "./chunk-WEXDXDMG.js";
import "./chunk-ZK6P7H22.js";
import "./chunk-45OQDK62.js";
import "./chunk-YBCPKXH5.js";
import "./chunk-JSFEMK6X.js";
import "./chunk-E5ECCKE6.js";
import "./chunk-3OV72XIM.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
