export interface Supplier {
  suppliersId?: number;
  suppliersName: string;
  suppliersPhone: string;
  suppliersEmail: string;
  suppliersContactPerson: string;
  address?: any;
}
