import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { UserService, User } from '../../services/user.service';
 
type ChangeType = 'positive' | 'negative';
 
interface Stat {
  icon: string;
  label: string;
  value: string;
  change: string;
  changeType: ChangeType;
}
 //changes done
interface Activity {
  icon: string;
  title: string;
  subtitle: string;
  wrapperBg?: string;
  iconColor?: string;
}
 
interface QuickAction {
  icon: string;
  title: string;
  subtitle: string;
  cardBg?: string;
  iconColor?: string;
}
 
@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],

  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  // header icons (kept as data if you want to show later)
  headerIcon = 'package';
  bellIcon = 'bell';
  settingsIcon = 'settings';
  logoutIcon = 'log-out';
 
  stats: Stat[] = [
    { icon: 'package',      label: 'Total Users',       value: '7',   change: '',        changeType: 'positive' },
    { icon: 'trending-up',  label: 'Orders Today',      value: '247', change: '+12.5%', changeType: 'positive' },
    { icon: 'users',        label: 'Active Suppliers',  value: '58',  change: '+1',     changeType: 'positive' },
    { icon: 'alert-triangle', label: 'Low Stock Alerts', value: '12',  change: '-3',     changeType: 'negative' },
  ];
 
  activities: Activity[] = [
    { icon: '📦', title: 'New stock received', subtitle: 'Office supplies - 150 units', wrapperBg: 'bg-blue-50', iconColor: 'text-blue-600' },
    { icon: '🚚', title: 'Order shipped', subtitle: 'Order #12847 - Electronics', wrapperBg: 'bg-green-50', iconColor: 'text-green-600' },
    { icon: '⚠️', title: 'Low stock alert', subtitle: 'Printer cartridges - 5 units left', wrapperBg: 'bg-amber-50', iconColor: 'text-amber-600' }
  ];
 
  quickActions: QuickAction[] = [
    { icon: '➕', title: 'Register User', subtitle: 'Add new system user', cardBg: 'card-blue', iconColor: 'text-blue-600' },
    { icon: '🔓', title: 'Unlock Users', subtitle: 'Unlock blocked users', cardBg: 'card-green', iconColor: 'text-green-600' },
    { icon: '🔑', title: 'Reset Password', subtitle: 'Reset credentials', cardBg: 'card-amber', iconColor: 'text-amber-600' }
  ];

  // Notifications dropdown
  notifications: string[] = [
    'Order #1023 has been approved',
    'New supplier added successfully',
    'Low stock alert: Product A'
  ];
  showNotifications = false;
 
 //changes done
  // Admin Users
  users: User[] = [];
  showAllUsers = false;
  loadingUsers = false;
  loadError: string | null = null;
 
  constructor(private router: Router, private userService: UserService) {}
 
  ngOnInit(): void {
    // If you want to guard this route client-side:
    const isAuthenticated = localStorage.getItem('isAuthenticated');
    if (!isAuthenticated) {
      this.router.navigate(['/login']);
      return;
    }
    this.loadUsers();
  }
 
  // small helper for CSS classes (kept from your earlier code)
  changeColor(type: ChangeType): string {
    return type === 'positive' ? 'text-green-600' : 'text-red-600';
  }

  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
  }
 
  // --- User management functions (wired to UI) ---
  loadUsers(): void {
    this.loadingUsers = true;
    this.loadError = null;
    this.userService.getAllUsers().subscribe({
      next: (data) => {
        this.users = data || [];
        this.loadingUsers = false;
      },
      error: (err) => {
        console.error('Failed to load users', err);
        this.loadError = 'Failed to load users';
        this.loadingUsers = false;
      }
    });
  }
 
  toggleUsers(): void {
    this.showAllUsers = !this.showAllUsers;
  }
 
  registerUser(): void {
    this.router.navigate(['/register']);
  }

  goToProfile() {
    this.router.navigate(['/profile']);
  }
 
  unlockUsers(): void {
    this.router.navigate(['/unlockuser']);
  }
 
  resetPassword(): void {
    this.router.navigate(['/reset-password']);
  }
 
  editUser(user: User): void {
    // navigate to update user route (assumes route exists)
    this.router.navigate(['/update-user', user.userId]);
  }
 
  deleteUser(userId: number | string): void {
    const idStr = String(userId);
    if (!confirm('Are you sure you want to delete this user?')) return;
 
    this.userService.deleteUser(idStr).subscribe({
      next: () => {
        // reload users to reflect change
        this.loadUsers();
      },
      error: (err) => {
        console.error('Failed to delete user', err);
        alert('Error deleting user');
      }
    });
  }
 
  logout(): void {
    // clear session data and redirect to landing (keeps behavior from your earlier code)
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userRole');
    this.router.navigate(['/']);
  }
}
 
 
