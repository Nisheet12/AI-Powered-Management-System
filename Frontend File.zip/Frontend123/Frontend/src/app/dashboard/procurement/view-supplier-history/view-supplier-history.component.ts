import { Component } from '@angular/core';

@Component({
  selector: 'app-view-supplier-history',
  standalone: true,
  imports: [],
  templateUrl: './view-supplier-history.component.html',
  styleUrl: './view-supplier-history.component.css'
})
export class ViewSupplierHistoryComponent {

}
