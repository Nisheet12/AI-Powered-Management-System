
// procurement.component.ts
import { Component } from '@angular/core';
import { Router, RouterModule, RouterOutlet} from '@angular/router';
import { InactivityService } from '../../services/inactivity.service';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { CommonModule } from '@angular/common';
 

@Component({
  selector: 'app-procurement-dashboard',
  standalone: true,
  templateUrl: './procurement.component.html',
  styleUrls: ['./procurement.component.css'],
  imports: [
    CommonModule,
    RouterModule,

    RouterOutlet,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule
  ],
})
export class ProcurementComponent {
constructor( private router: Router, private inactivityService: InactivityService) {}

   updatepassword(){
    this.router.navigate(['/reset-password'])
  }

  menuOpen = false;

trackOrder(orderId: number): void {
    this.router.navigate(['/procurement/track-order', orderId]);
  }

  createOrder(): void {
    this.router.navigate(['/procurement/create-order']);
  }

  goToProfile() {
    this.router.navigate(['/profile']);
  }

  toggleMenu() {
  this.menuOpen = !this.menuOpen;
}

  updateOrder(orderId: number): void {
    this.router.navigate(['/procurement/update-order', orderId]);
  }

  cancelOrder(orderId: number): void {
    this.router.navigate(['/procurement/cancel-order', orderId]);
  }

  customerOrder(): void {
    this.router.navigate(['/procurement/customer-order']);
  }

  retuenOrder(orderId: number): void{
    this.router.navigate(['/procurement/return-order']);
  }

  logout(){
    this.inactivityService.logout();
  }

  Payment() {
    this.router.navigate(['/payment']);
  }

}
 
