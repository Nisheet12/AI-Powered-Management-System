import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SupplierPayment, SupplierPaymentService, } from '../../../services/supplier-payment.service';


@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterLink],
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class SPaymentComponent implements OnInit {
  // Create form
  createForm = this.fb.group({
    suppliersId: [null, [Validators.required]],
    suppliersName: [''], // optional — backend uses only id
    invoiceNumber: ['', [Validators.required]],
    invoiceDate: ['', [Validators.required]],
    dueDate: ['', [Validators.required]],
    amount: [null, [Validators.required, Validators.min(0.01)]]
  });

  creating = false;
  createError = '';

  // List + actions
  payments: SupplierPayment[] = [];
  loading = false;
  loadError = '';
  payAmount: Record<number, number> = {};  // inline amount keyed by paymentId

  // Simple filters
  supplierFilter: number | null = null;
  onlyOutstanding = false;

  constructor(
    private fb: FormBuilder,
    private api: SupplierPaymentService
  ) {}

  ngOnInit(): void {
    this.load();
  }

  // ---- Create ----
  submitCreate(): void {
    if (this.createForm.invalid) { this.createForm.markAllAsTouched(); return; }
    this.creating = true; this.createError = '';

    const v = this.createForm.value;
    const payload: SupplierPayment = {
      supplier: { suppliersId: Number(v.suppliersId), suppliersName: v.suppliersName || undefined },
      invoiceNumber: v.invoiceNumber!,
      invoiceDate: v.invoiceDate!, // yyyy-MM-dd
      dueDate: v.dueDate!,
      amount: Number(v.amount)
    };

    this.api.createPayment(payload).subscribe({
      next: () => {
        this.creating = false;
        this.createForm.reset();
        this.load(); // refresh list
      },
      error: err => {
        this.createError = err?.error?.error || 'Create failed';
        this.creating = false;
      }
    });
  }

  // ---- List / Filters ----
  load(): void {
    this.loading = true; this.loadError = '';
    const req$ =
      this.supplierFilter
        ? this.api.getBySupplier(this.supplierFilter)
        : (this.onlyOutstanding ? this.api.getOutstanding() : this.api.getAll());

    req$.subscribe({
      next: res => { this.payments = res; this.loading = false; },
      error: err => { this.loadError = err?.error?.error || 'Failed to load'; this.loading = false; }
    });
  }

  resetFilters(): void {
    this.supplierFilter = null;
    this.onlyOutstanding = false;
    this.load();
  }

  // ---- Actions ----
  pay(p: SupplierPayment): void {
    const amt = this.payAmount[p.paymentId!];
    if (!amt || amt <= 0) { alert('Enter a positive amount'); return; }

    this.api.applyPayment(p.paymentId!, amt).subscribe({
      next: updated => {
        const idx = this.payments.findIndex(x => x.paymentId === updated.paymentId);
        if (idx > -1) this.payments[idx] = updated;
        this.payAmount[p.paymentId!] = 0;
      },
      error: err => alert(err?.error?.error || 'Payment failed')
    });
  }

  remove(p: SupplierPayment): void {
    if (!confirm(`Delete payment ${p.invoiceNumber}?`)) return;
    this.api.delete(p.paymentId!).subscribe({
      next: () => this.payments = this.payments.filter(x => x.paymentId !== p.paymentId),
      error: err => alert(err?.error?.error || 'Delete failed')
    });
  }
}
