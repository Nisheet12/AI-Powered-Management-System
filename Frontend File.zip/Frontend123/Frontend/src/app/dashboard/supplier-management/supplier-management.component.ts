import { Component } from '@angular/core';

@Component({
  selector: 'app-supplier-management',
  standalone: true,
  imports: [],
  templateUrl: './supplier-management.component.html',
  styleUrl: './supplier-management.component.css'
})
export class SupplierManagementComponent {

}
