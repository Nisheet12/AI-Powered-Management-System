import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SupplierService } from '../../../services/suppliers.service';
import { Supplier } from '../../../models/supplier.model';

@Component({
  selector: 'app-supplier-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './supplier-form.component.html',
  styleUrls: ['./supplier-form.component.css']
})
export class SupplierFormComponent implements OnInit {
  supplierForm!: FormGroup;
  isEdit = false;
  supplierId!: number;

  constructor(
    private fb: FormBuilder,
    private supplierService: SupplierService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.supplierForm = this.fb.group({
      suppliersName: ['', Validators.required],
      suppliersPhone: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      suppliersEmail: ['', [Validators.required, Validators.email]],
      suppliersContactPerson: ['', Validators.required],
      address: [''] // ✅ ensure backend mapping works
    });

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.supplierId = +id;
      this.supplierService.getSupplierById(this.supplierId).subscribe((data: Supplier) => {
        this.supplierForm.patchValue(data);
      });
    }
  }

  onSubmit() {
    if (this.supplierForm.invalid) return;
    const supplier = this.supplierForm.value;

    if (this.isEdit) {
      this.supplierService.updateSupplier(this.supplierId, supplier).subscribe(() => {
        alert('✅ Supplier updated successfully!');
        this.router.navigate(['/dashboard/supplier-management/list']);
      });
    } else {
      this.supplierService.addSupplier(supplier).subscribe(() => {
        alert('✅ Supplier added successfully!');
        this.router.navigate(['/dashboard/supplier-management/list']);
      });
    }
  }

  cancel() {
    this.router.navigate(['/dashboard/supplier-management/list']);
  }
}
