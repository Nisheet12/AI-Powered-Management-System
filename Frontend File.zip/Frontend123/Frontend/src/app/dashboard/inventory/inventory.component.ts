// inventory-dashboard.component.ts
import { Component, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { InactivityService } from '../../services/inactivity.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
 
 
@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  standalone: true,
  imports: [RouterModule],
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent  implements OnInit, OnDestroy{
    username = 'User';
    showProfileMenu = false;
 
    private docClickUnlistener!: () => void;
constructor( private inactivityService: InactivityService,
     private router: Router,
   
      private http: HttpClient,
      private renderer: Renderer2
) {}

 
 logout(){
    this.inactivityService.logout();
  }
 
    ngOnInit(): void {
      // Try basic localStorage username first
      const lsName = localStorage.getItem('username');
      if (lsName && lsName.trim().length) {
        this.username = lsName;
      } else {
        // Fallback: try decode JWT token payload (if your token contains user info)
        const token = localStorage.getItem('token');
        const fromToken = this.getUsernameFromToken(token);
        if (fromToken) this.username = fromToken;
      }
 
      console.log('Dashboard username:', this.username);
     
 
      // close profile dropdown when clicking outside
      this.docClickUnlistener = this.renderer.listen('document', 'click', (evt: Event) => {
        if (this.showProfileMenu) {
          this.showProfileMenu = false;
        }
      });
    }
 
    ngOnDestroy(): void {
      if (this.docClickUnlistener) this.docClickUnlistener();
    }
 
    getUsernameFromToken(token: string | null): string | null {
      if (!token) return null;
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        // common fields: username, sub, name, email
        return payload.username || payload.sub || payload.name || null;
      } catch (e) {
        return null;
      }
    }
 
   
 
    toggleProfileMenu(event?: Event) {
      if (event) event.stopPropagation();
      this.showProfileMenu = !this.showProfileMenu;
    }
 
    viewProfile() {
      this.showProfileMenu = false;
      this.router.navigate(['/view-profile']);
    }


    goToProfile() {
      this.router.navigate(['/profile']);
    }

 
    updatePassword() {
     this.showProfileMenu = false;
      this.router.navigate(['/reset-password']);
    }
 
    productStock(){
      this.router.navigate(['/inventory/product-stock-view']);
    }

    productionTracking() {
    this.router.navigate(['/inventory/production-tracking']);
  }

  product() {
    this.router.navigate(['/inventory/product']);
  }

  productionschedule() {
    this.router.navigate(['/inventory/production-schedule']);
  }

  report() {
    this.router.navigate(['/inventory/report']);
  }
}