import { Routes } from '@angular/router';

import { LandingPageComponent } from './components/landing-page/landing-page.component';
import { LoginPageComponent } from './components/login-page/login-page.component';
import { FooterComponent } from './components/footer/footer.component';
import { AdminComponent } from './dashboard/admin/admin.component';
import { ProcurementComponent } from './dashboard/procurement/procurement.component';
import { ProductionComponent } from './dashboard/production/production.component';
import { InventoryComponent } from './dashboard/inventory/inventory.component';
import { ResetPasswordComponent } from './password/reset-password/reset-password.component';
import { ForgotPasswordComponent } from './password/forgotpassword/forgotpassword.component';
import { RegisterComponent } from './dashboard/register/register.component';
import { UnlockUserComponent } from './dashboard/unlock-user/unlock-user.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { OrderHistoryComponent } from './dashboard/procurement/order-history/order-history.component';
import { TrackOrderComponent } from './dashboard/procurement/track-order/track-order.component';
import { ReturnOrderComponent } from './dashboard/procurement/return-order/return-order.component';
import { authGuard } from './auth.guard';
import { PaymentComponent } from './payment/payment.component';
import { OrderCancelComponent } from './dashboard/procurement/cancel-order/cancel-order.component';
import { UpdateOrderComponent } from './dashboard/procurement/update-order/update-order.component';
import { SupplierOrderCreateComponent } from './dashboard/procurement/create-order/create-order.component';
import { CustomerOrderComponent } from './dashboard/procurement/customer-order/customer-order.component';
import { ProductStockViewComponent } from './dashboard/inventory/product-stock-view/product-stock-view.component';
import { ProductionTrackingComponent } from './dashboard/inventory/production-tracking/production-tracking.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ProductComponent } from './dashboard/inventory/product/product.component';
import { ReportComponent } from './dashboard/inventory/report/report.component';
import { POPaymentComponent } from './dashboard/procurement/popayment/popayment.component';
import { HomeComponent } from './dashboard/procurement/home/home.component';
import { ProductionTimelineComponent } from './dashboard/production/production-timeline/production-timeline.component';
import { SPaymentComponent } from './dashboard/procurement/payment/payment.component';
import { ProductionTimelineDetailComponent } from './dashboard/production/production-timeline-detail/production-timeline-detail.component';
import { ProductionAnalyticsComponent } from './dashboard/production/production-analytics/production-analytics.component';
import { ProductionScheduleComponent } from './dashboard/production/production-schedule/production-schedule.component';
import { SupplierFormComponent } from './dashboard/supplier-management/supplier-form/supplier-form.component';
import { SupplierListComponent } from './dashboard/supplier-management/supplier-list/supplier-list.component';
 
// ✅ Correct path: use production dashboard schedule component
 
export const routes: Routes = [
  // ✅ Default Landing & Login
  { path: '', component: LandingPageComponent, pathMatch: 'full' },
  { path: 'login', component: LoginPageComponent },
  { path: 'footer', component: FooterComponent },

  // ✅ Admin
  { path: 'admin', component: AdminComponent, canActivate: [authGuard] },

  // ✅ Procurement
  {
    path: 'procurement',
    component: ProcurementComponent,
    canActivate: [authGuard],
    children: [
      { path: 'orders', component: OrderHistoryComponent },
      { path: 'track-order/:id', component: TrackOrderComponent },
      { path: 'track-order', component: TrackOrderComponent },
      { path: 'return-order', component: ReturnOrderComponent },
      { path: 'home', component: HomeComponent },
      { path: 'create-order', component: SupplierOrderCreateComponent },
      { path: 'update-order', component: UpdateOrderComponent },
      { path: 'cancel-order', component: OrderCancelComponent },
      { path: 'customer-order', component: CustomerOrderComponent },
      { path: 'popayment', component: POPaymentComponent },
      {path:"payment",component:SPaymentComponent},
      { path: '', redirectTo: 'home', pathMatch: 'full' }
    ]
  },

  // ✅ Production
  {
    path: 'production',
    component: ProductionComponent,
    canActivate: [authGuard],
    children: [
      { path: '', redirectTo: 'timeline', pathMatch: 'full' },
      { path: 'timeline', component: ProductionTimelineComponent },
      { path: 'timeline/:psId', component: ProductionTimelineDetailComponent },
      { path: 'schedule', component: ProductionScheduleComponent },
      { path: 'analytics', component: ProductionAnalyticsComponent }
    ]
  },

  // ✅ Inventory
  {
    path: 'inventory',
    component: InventoryComponent,
    canActivate: [authGuard],
    children: [
      { path: 'product-stock-view', component: ProductStockViewComponent },
      { path: 'production-tracking', component: ProductionTrackingComponent },
      { path: 'product', component: ProductComponent },
      { path: 'report', component: ReportComponent },
      { path: '', redirectTo: 'product-stock-view', pathMatch: 'full' }
    ]
  },

  // ✅ Supplier Management
  {
    path: 'dashboard/supplier-management',
    canActivate: [authGuard],
    children: [
      { path: 'list', component: SupplierListComponent },
      { path: 'add', component: SupplierFormComponent },
      { path: 'edit/:id', component: SupplierFormComponent },
      { path: '', redirectTo: 'list', pathMatch: 'full' }
    ]
  },

  // ✅ Payments
  { path: 'payments/pay', component: PaymentComponent },

  // ✅ Auth & User Management
  { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
  { path: 'reset-password', component: ResetPasswordComponent, canActivate: [authGuard] },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'register', component: RegisterComponent, canActivate: [authGuard] },
  { path: 'update-user/:id', component: UpdateUserComponent, canActivate: [authGuard] },
  { path: 'unlockuser', component: UnlockUserComponent, canActivate: [authGuard] },

  // ✅ Wildcard fallback (always last)
  { path: '**', redirectTo: '' }
];
